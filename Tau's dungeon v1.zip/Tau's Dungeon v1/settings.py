import pygame as pg

# define some colors (R, G, B)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
DARKGREY = (40, 40, 40)
LIGHTGREY = (100, 100, 100)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
PINK = (240, 129, 214)
WALL_COLOUR = (194, 88, 39)

# game settings
WIDTH = 16 * 32
HEIGHT = 16 * 24
FPS = 30
TITLE = "Tau's Dungeon"
BGCOLOR = (199, 179, 145)
GRIDCOLOUR = (120, 120, 120)
TILESIZE = 32

WALL_IMG = 'tiles/wall_1.png'
GROUND_IMG = 'tiles/ground_1.png'

# player settings
PLAYER_SPEED = 256
PLAYER_ANIM_SPEED = int(5/32*FPS)  # Time between animations
PLAYER_ROT_SPEED = 250
PLAYER_HIT_RECT = pg.Rect(0, 0, 25, 25)
PLAYER_D1 = 'characters/p_down1.png'
PLAYER_D2 = 'characters/p_down2.png'
PLAYER_D3 = 'characters/p_down3.png'
PLAYER_U1 = 'characters/p_up1.png'
PLAYER_U2 = 'characters/p_up2.png'
PLAYER_U3 = 'characters/p_up3.png'
PLAYER_L1 = 'characters/p_left1.png'
PLAYER_L2 = 'characters/p_left2.png'
PLAYER_BH = 'characters/p_bullet_hell.png'

# gun settings
BULLET_IMG = 'objects/bullet_1.png'
BULLET_SPEED = 500
BULLET_LIFETIME = 1000
BULLET_RATE = 150

# mob settings
MOB_SPEED = 150
MOB_HIT_RECT = pg.Rect(0, 0, 30, 30)
MOB_IMG = 'characters/e_slime1.png'

GRIDWIDTH = WIDTH / TILESIZE
GRIDHEIGHT = HEIGHT / TILESIZE
