import pygame as pg
from settings import *
from tilemap import collide_hit_rect
vec = pg.math.Vector2


def collide_with_walls(sprite, group, dir):
    if dir == 'x':
        hits = pg.sprite.spritecollide(sprite, group, False, collide_hit_rect)
        if hits:
            if sprite.vel.x > 0:
                sprite.pos.x = hits[0].rect.left - sprite.hit_rect.width / 2
            if sprite.vel.x < 0:
                sprite.pos.x = hits[0].rect.right + sprite.hit_rect.width / 2
            sprite.vel.x = 0
            sprite.hit_rect.centerx = sprite.pos.x
    if dir == 'y':
        hits = pg.sprite.spritecollide(sprite, group, False, collide_hit_rect)
        if hits:
            if sprite.vel.y > 0:
                sprite.pos.y = hits[0].rect.top - sprite.hit_rect.height / 2
            if sprite.vel.y < 0:
                sprite.pos.y = hits[0].rect.bottom + sprite.hit_rect.height / 2
            sprite.vel.y = 0
            sprite.hit_rect.centery = sprite.pos.y


class Player(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.images = game.plr_images
        self.animation_index = 0
        self.image = self.images[self.animation_index]
        self.time_since_anim = 0
        self.direction = "d"
        self.control_mode = "player"
        self.base_speed = PLAYER_SPEED
        self.rect = self.image.get_rect()
        self.hit_rect = PLAYER_HIT_RECT
        self.hit_rect.center = self.rect.center
        self.vel = vec(0, 0)
        self.pos = vec(x, y) * TILESIZE
        self.rot = 0  # Unused
        self.rot_speed = PLAYER_ROT_SPEED  # Unused
        self.last_shot = 0

    def get_keys(self):
        self.vel = vec(0, 0)
        keys = pg.key.get_pressed()  # Get all pressed keys
        if keys[pg.K_LEFT] or keys[pg.K_a]:  # Move left
            self.direction = "l"
            self.vel.x = -self.base_speed
        if keys[pg.K_RIGHT] or keys[pg.K_d]:  # Move right
            self.direction = "r"
            self.vel.x = self.base_speed
        if keys[pg.K_UP] or keys[pg.K_w]:  # Move up
            self.direction = "u"
            self.vel.y = -self.base_speed
        if keys[pg.K_DOWN] or keys[pg.K_s]:  # Move down
            self.direction = "d"
            self.vel.y = self.base_speed
        if keys[pg.K_h]:  # Testing use only
            self.change_control_type()
        if keys[pg.K_SPACE] and self.control_mode == "bullet_hell":
            now = pg.time.get_ticks()
            if now - self.last_shot > BULLET_RATE:
                self.last_shot = now
                dir = vec(1, 0).rotate(-self.rot)
                Bullet(self.game, self.pos, dir)
        if self.vel.x != 0 and self.vel.y != 0:  # Make diagonal speed just as fast as orthogonal
            self.vel *= 0.7071

    def change_control_type(self):
        if self.control_mode == "player":
            self.control_mode = "bullet_hell"
            self.image = self.images[-1]
            self.base_speed = 400
            self.hit_rect = pg.Rect(0, 0, 10, 14)
        else:
            self.control_mode = "player"
            self.base_speed = PLAYER_SPEED
            self.hit_rect = pg.Rect(0, 0, 25, 25)
        pg.time.wait(100)

    def update(self):
        self.get_keys()
        if not self.game.paused:
            # self.rot = (self.rot + self.rot_speed * self.game.dt) % 360  # Unused as player doesn't rotate
            # self.image = pg.transform.rotate(self.image, self.rot)  # Unused
            self.rect = self.image.get_rect()
            self.rect.center = self.pos
            self.pos += self.vel * self.game.dt
            self.hit_rect.centerx = self.pos.x
            collide_with_walls(self, self.game.walls, 'x')
            self.hit_rect.centery = self.pos.y
            collide_with_walls(self, self.game.walls, 'y')
            self.rect.center = self.hit_rect.center
            if self.control_mode == "player":  # Only do walking updates in player mode
                self.update_img()

    def update_img(self):
        self.time_since_anim += 1
        if self.time_since_anim == PLAYER_ANIM_SPEED:
            self.time_since_anim = 0
        if self.time_since_anim == 0:  # Only change animation once every cycle
            if not self.vel == vec(0, 0):  # Only animate if the player is moving
                if self.direction == "u":
                    if self.animation_index == 5:
                        self.animation_index = 3
                    else:
                        self.animation_index = 5
                elif self.direction == "d":
                    if self.animation_index == 0:
                        self.animation_index = 2
                    else:
                        self.animation_index = 0
                else:
                    if self.animation_index == 7:
                        self.animation_index = 6
                    else:
                        self.animation_index = 7

            self.image = self.images[self.animation_index]
            if self.direction == "r":  # Right-facing sprite is just a mirror of the left
                self.image = pg.transform.flip(self.image, True, False)


class Mob(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.mobs
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.mob_img
        self.rect = self.image.get_rect()
        self.hit_rect = MOB_HIT_RECT.copy()
        self.hit_rect.center = self.rect.center
        self.pos = vec(x, y) * TILESIZE
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        self.rect.center = self.pos
        self.rot = 0

    def update(self):
        self.rot = (self.game.player.pos - self.pos).angle_to(vec(1, 0))
        self.image = pg.transform.rotate(self.game.mob_img, self.rot)
        self.rect = self.image.get_rect()
        self.rect.center = self.pos
        self.acc = vec(MOB_SPEED, 0).rotate(-self.rot)
        self.acc += self.vel * -1  # Friction
        self.vel += self.acc * self.game.dt
        self.pos += self.vel * self.game.dt + 0.5 * self.acc * self.game.dt ** 2
        self.hit_rect.centerx = self.pos.x
        collide_with_walls(self, self.game.walls, 'x')
        self.hit_rect.centery = self.pos.y
        collide_with_walls(self, self.game.walls, 'y')
        self.rect.center = self.hit_rect.center


class Bullet(pg.sprite.Sprite):
    def __init(self, game, pos, dir):
        self.game = game
        self.groups = game.all_sprites, game.bullets
        pg.sprite.Sprite.__init__(self, self.groups)
        self.image = game.bullet_img
        self.rect = self.image.get_rect()
        self.pos = pos
        self.rect.center = pos
        self.vel = dir * BULLET_SPEED
        self.spawn_time = pg.time.get_ticks()

    def update(self):
        self.pos += self.vel * self.game.dt
        self.rect.center = self.pos
        if pg.time.get_ticks() - self.spawn_time > BULLET_LIFETIME:
            self.kill()  # 0_0


class Wall(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self.groups = game.all_sprites, game.walls
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.wall_img
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        self.rect.x = x * TILESIZE
        self.rect.y = y * TILESIZE
